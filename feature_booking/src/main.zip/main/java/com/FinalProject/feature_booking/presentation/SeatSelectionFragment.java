package com.FinalProject.feature_booking.presentation;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.gridlayout.widget.GridLayout;
import androidx.navigation.fragment.NavHostFragment;

import com.FinalProject.feature_booking.R;
import com.FinalProject.feature_booking.model.SeatState;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.snackbar.Snackbar;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public class SeatSelectionFragment extends Fragment {

    private static final int MAX_SELECT = 4;

    private String eventId, showId;
    private GridLayout grid;
    private TextView tvSelected, tvTotal;
    private View btnNext;

    private final Map<String, SeatState> stateBySeat = new HashMap<>();
    private final LinkedHashSet<String> selected = new LinkedHashSet<>();

    public SeatSelectionFragment() {
        super(R.layout.fragment_seat_selection);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();
        if (args != null) {
            eventId = args.getString("eventId", "");
            showId  = args.getString("showId", "");
        }

        grid       = view.findViewById(R.id.grid_seats);
        tvSelected = view.findViewById(R.id.tv_selected_seats);
        tvTotal    = view.findViewById(R.id.tv_total_price);
        btnNext    = view.findViewById(R.id.btn_proceed_checkout);

        initSeats();

        btnNext.setOnClickListener(v -> {
            ArrayList<String> list = new ArrayList<>(selected);
            long total = computeTotal();

            Bundle toCheckout = new Bundle();
            toCheckout.putString("eventId", eventId);
            toCheckout.putString("showId",  showId);
            toCheckout.putStringArray("selectedSeats", list.toArray(new String[0]));
            toCheckout.putLong("totalPrice", total);

            NavHostFragment.findNavController(this)
                    .navigate(R.id.action_seatSelection_to_checkout, toCheckout);
        });

        renderSummary();
    }

    /** Demo pricing theo hàng */
    private long priceOf(String seat) {
        char row = seat.charAt(0);
        if (row == 'A') return 350_000;
        if (row == 'B') return 220_000;
        return 120_000;
    }

    private void initSeats() {
        Set<String> reserved = new HashSet<>(Arrays.asList("A3","B4"));

        for (int i = 0; i < grid.getChildCount(); i++) {
            View child = grid.getChildAt(i);
            if (!(child instanceof MaterialButton)) continue;

            MaterialButton btn = (MaterialButton) child;

            // ✨ Quan trọng: tắt checkable & checked để MaterialButton không tự toggle
            btn.setCheckable(false);
            btn.setChecked(false);

            Object t = child.getTag();
            final String seat = (t == null) ? ("S" + i) : t.toString();
            btn.setText(seat);

            SeatState init = reserved.contains(seat) ? SeatState.RESERVED : SeatState.AVAILABLE;
            stateBySeat.put(seat, init);
            applySeatStyle(btn, init);

            btn.setOnClickListener(v -> onSeatClicked(seat, btn));
        }
    }
    private void applySeatStyle(@NonNull MaterialButton btn, @NonNull SeatState st) {
        // Tuyệt đối không cho MaterialButton tự toggle
        btn.setCheckable(false);
        btn.setChecked(false);

        // Tránh kẹt trạng thái nhấn/hover khi bị chặn chọn quá số lượng
        btn.setPressed(false);
        btn.setHovered(false);

        // Nếu dùng stroke/outline của MaterialButton Tonal/Outlined
        btn.setIcon(null);                 // không icon
        btn.setStrokeWidth(2);             // viền mảnh cho đồng nhất
        btn.setCornerRadius(14);           // bo góc nhẹ (API 28+)

        switch (st) {
            case RESERVED:
                btn.setEnabled(false);
                btn.setBackgroundResource(R.drawable.bg_seat_reserved);
                btn.setTextColor(requireContext().getColor(android.R.color.darker_gray));
                break;

            case SELECTED:
                btn.setEnabled(true);
                btn.setBackgroundResource(R.drawable.bg_seat_selected);
                btn.setTextColor(requireContext().getColor(android.R.color.white));
                break;

            case AVAILABLE:
            default:
                btn.setEnabled(true);
                btn.setBackgroundResource(R.drawable.bg_seat_available);
                btn.setTextColor(0xFF222222); // hoặc requireContext().getColor(R.color.your_text_color)
                break;
        }

        // (tuỳ chọn) giảm ripple để nền custom không bị “nhuộm”
        btn.setRippleColorResource(android.R.color.transparent);
    }
    private void onSeatClicked(String seat, MaterialButton btn) {
        SeatState cur = stateBySeat.get(seat);
        if (cur == SeatState.RESERVED) return;

        if (cur == SeatState.AVAILABLE) {
            if (selected.size() >= MAX_SELECT) {
                Snackbar.make(requireView(),
                        "Bạn chỉ có thể chọn tối đa " + MAX_SELECT + " ghế.",
                        Snackbar.LENGTH_SHORT).show();

                // ✨ Ép nút trở về trạng thái AVAILABLE nếu framework vừa “nhuộm” pressed/checked
                btn.setPressed(false);
                btn.setHovered(false);
                applySeatStyle(btn, SeatState.AVAILABLE);
                return;
            }
            stateBySeat.put(seat, SeatState.SELECTED);
            selected.add(seat);
            applySeatStyle(btn, SeatState.SELECTED);

        } else { // SELECTED -> bỏ chọn
            stateBySeat.put(seat, SeatState.AVAILABLE);
            selected.remove(seat);
            applySeatStyle(btn, SeatState.AVAILABLE);
        }
        renderSummary();
    }

    private long computeTotal() {
        long sum = 0;
        for (String s : selected) sum += priceOf(s);
        return sum;
    }

    private void renderSummary() {
        if (selected.isEmpty()) {
            tvSelected.setText("Chưa chọn ghế");
        } else {
            tvSelected.setText("Ghế: " + String.join(", ", selected));
        }
        long total = computeTotal();
        tvTotal.setText("Tổng tiền: " +
                NumberFormat.getCurrencyInstance(new Locale("vi", "VN")).format(total));
        btnNext.setEnabled(!selected.isEmpty());
    }
}
