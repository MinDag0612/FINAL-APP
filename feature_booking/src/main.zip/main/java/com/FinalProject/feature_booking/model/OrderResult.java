package com.FinalProject.feature_booking.model;

public class OrderResult {
    private final String orderId;
    public OrderResult(String orderId) { this.orderId = orderId; }
    public String getOrderId() { return orderId; }
}
