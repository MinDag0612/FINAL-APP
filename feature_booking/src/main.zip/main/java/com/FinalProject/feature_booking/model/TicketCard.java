package com.FinalProject.feature_booking.model;

public class TicketCard {
    private final String eventId, title, time, seats;
    private final TicketStatus status;

    public TicketCard(String eventId, String title, String time, String seats, TicketStatus status) {
        this.eventId = eventId; this.title = title; this.time = time; this.seats = seats; this.status = status;
    }
    public String getEventId(){ return eventId; }
    public String getTitle(){ return title; }
    public String getTime(){ return time; }
    public String getSeats(){ return seats; }
    public TicketStatus getStatus(){ return status; }
}
