package com.FinalProject.feature_booking.model;

public class TicketSelection {
    private String typeId;
    private int quantity;
    private long unitPrice;

    public TicketSelection(String typeId, int quantity, long unitPrice) {
        this.typeId = typeId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    public String getTypeId() { return typeId; }
    public int getQuantity() { return quantity; }
    public long getUnitPrice() { return unitPrice; }
    public void setQuantity(int q) { this.quantity = q; }
}
