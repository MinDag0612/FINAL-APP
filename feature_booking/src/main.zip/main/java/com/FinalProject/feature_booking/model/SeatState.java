package com.FinalProject.feature_booking.model;
public enum SeatState { AVAILABLE, SELECTED, RESERVED }
