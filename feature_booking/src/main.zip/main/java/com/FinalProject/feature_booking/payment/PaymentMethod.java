package com.FinalProject.feature_booking.payment;

public enum PaymentMethod {
    CARD, WALLET, QR
}
