package com.FinalProject.feature_booking.presentation;

import com.FinalProject.feature_booking.R;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.FinalProject.feature_booking.payment.PaymentCallback;
import com.FinalProject.feature_booking.payment.PaymentMethod;
import com.FinalProject.feature_booking.payment.PaymentOrchestrator;
import com.FinalProject.feature_booking.payment.PaymentRequest;
import com.FinalProject.feature_booking.payment.PaymentResult;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import android.text.Editable;
import android.text.TextWatcher;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public class CheckoutFragment extends Fragment {

    private static final double SERVICE_FEE_RATE = 0.03;
    private static final long   SERVICE_FEE_MIN  = 3000;

    private TextView tvEventTitle, tvSeats, tvQuantity, tvTicketPrice, tvServiceFee, tvTotal;

    // Dòng "Giảm giá"
    private View rowDiscount;           // @id/ll_row_discount
    private TextView tvDiscount;        // @id/tv_checkout_discount

    // 3 nút phương thức (single-select)
    private MaterialButton btnCard, btnWallet, btnQr;
    private List<MaterialButton> paymentButtons;

    private MaterialButton btnConfirm;

    private String eventId;
    private String showId;
    private String eventTitleArg = "Sự kiện";
    private ArrayList<String> seats = new ArrayList<>();
    private long ticketPrice = 0L;

    private final NumberFormat vnd = NumberFormat.getCurrencyInstance(new Locale("vi", "VN"));
    private final PaymentOrchestrator payments = new PaymentOrchestrator();

    // Trạng thái
    private boolean isProcessing = false;
    private boolean paymentLocked = false;
    private PaymentMethod selectedMethod = PaymentMethod.CARD;
    private boolean isAuthorized = false;
    private PaymentMethod authorizedMethod = null;
    private PaymentResult lastPaymentResult = null;

    // Promo
    private TextInputLayout tilPromo;           // @id/til_promo (nếu có)
    private TextInputEditText etPromo;          // @id/et_promo (nếu có)
    private String appliedPromoCode = "";       // ✅ CHỈ set khi bấm icon check & hợp lệ

    // Dialog processing
    private AlertDialog processingDialog;
    private View processingView;
    private ProgressBar progressBar;
    private View ivTick;
    private TextView tvProcessingMsg;
    private final Handler ui = new Handler(Looper.getMainLooper());

    public CheckoutFragment() { super(R.layout.fragment_checkout); }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvEventTitle   = view.findViewById(R.id.tv_checkout_event_title);
        tvSeats        = view.findViewById(R.id.tv_checkout_seats);
        tvQuantity     = view.findViewById(R.id.tv_checkout_quantity);
        tvTicketPrice  = view.findViewById(R.id.tv_checkout_ticket_price);
        tvServiceFee   = view.findViewById(R.id.tv_checkout_service_fee);
        tvTotal        = view.findViewById(R.id.tv_checkout_total);

        rowDiscount    = view.findViewById(R.id.ll_row_discount);
        tvDiscount     = view.findViewById(R.id.tv_checkout_discount);

        btnCard   = view.findViewById(R.id.btn_payment_card);
        btnWallet = view.findViewById(R.id.btn_payment_wallet);
        btnQr     = view.findViewById(R.id.btn_payment_qr);
        paymentButtons = Arrays.asList(btnCard, btnWallet, btnQr);
        for (MaterialButton b : paymentButtons) if (b != null) b.setCheckable(true);

        btnConfirm = view.findViewById(R.id.btn_confirm_payment);

        // Promo field
        tilPromo = view.findViewById(R.id.til_promo);
        if (tilPromo == null) tilPromo = findFirstTextInputLayout((ViewGroup) view);
        if (tilPromo != null) {
            etPromo = view.findViewById(R.id.et_promo);
            if (etPromo == null) etPromo = (TextInputEditText) tilPromo.getEditText();
            setupPromoField(); // chỉ áp dụng khi bấm icon ✅
        }

        // Args
        Bundle args = getArguments();
        if (args != null) {
            eventId      = args.getString("eventId", "");
            showId       = args.getString("showId", "");
            eventTitleArg= args.getString("eventTitle", "Sự kiện");
            String[] arr = args.getStringArray("selectedSeats");
            if (arr != null) seats = new ArrayList<>(Arrays.asList(arr));
            ticketPrice  = args.getLong("totalPrice", 0L);
        }

        // UI ban đầu
        tvEventTitle.setText(eventTitleArg);
        tvSeats.setText("Ghế: " + (seats.isEmpty() ? "-" : String.join(", ", seats)));
        tvQuantity.setText("Số lượng vé: " + seats.size());

        setSelection(PaymentMethod.CARD);

        // Chọn phương thức ⇒ authorize
        View.OnClickListener choose = v -> {
            if (isProcessing) return;
            if (paymentLocked) {
                Snackbar.make(requireView(),
                        "Thanh toán đã được xác nhận. Không thể thay đổi phương thức.",
                        Snackbar.LENGTH_SHORT).show();
                return;
            }
            PaymentMethod tapped = idToMethod(v.getId());
            if (tapped == null) return;
            setSelection(tapped);
            startAuthorize(tapped);
        };
        btnCard.setOnClickListener(choose);
        btnWallet.setOnClickListener(choose);
        btnQr.setOnClickListener(choose);

        // Nhận vé
        btnConfirm.setEnabled(false);
        btnConfirm.setOnClickListener(v -> {
            if (isProcessing) return;
            if (!isAuthorized || authorizedMethod == null) {
                Snackbar.make(requireView(), "Vui lòng xác nhận phương thức thanh toán trước.", Snackbar.LENGTH_SHORT).show();
                return;
            }
            Bundle bundle = buildTicketBundle();
            NavController navController = NavHostFragment.findNavController(this);
            // Dùng ACTION trong nav_graph để popUpTo hoạt động đúng
            navController.navigate(R.id.action_checkout_to_myTickets, bundle);
        });
    }

    // ---------------- Promo: chỉ áp dụng khi bấm icon ✅ ----------------
    private void setupPromoField() {
        if (tilPromo == null) return;

        tilPromo.setError(null);

        try {
            tilPromo.setEndIconMode(TextInputLayout.END_ICON_CUSTOM);
            tilPromo.setEndIconDrawable(R.drawable.ic_check_24);
            tilPromo.setEndIconContentDescription("Áp dụng mã");
            tilPromo.setEndIconOnClickListener(v -> {
                String code = getPromoText();
                if (isValidPromo(code)) {
                    appliedPromoCode = code.toUpperCase(Locale.ROOT);      // ✅ chỉ set khi hợp lệ
                    tilPromo.setError(null);
                    tilPromo.setHelperText("Đã áp dụng: " + appliedPromoCode + " (-10%)");
                } else {
                    appliedPromoCode = "";                                  // không hợp lệ → không áp dụng
                    tilPromo.setHelperText(null);
                    tilPromo.setError("Mã không hợp lệ (chấp nhận: GIAM10, SALE10)");
                }
                hideKeyboard();
                recalcTotalsFor(selectedMethod);
            });
        } catch (Exception ignore) {}

        if (etPromo != null) {
            etPromo.addTextChangedListener(new TextWatcher() {
                @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
                @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
                @Override public void afterTextChanged(Editable s) {
                    // Gõ lại ⇒ hủy mã đã áp dụng (yêu cầu nhấn ✓ lại)
                    if (!appliedPromoCode.isEmpty()) {
                        appliedPromoCode = "";
                    }
                    tilPromo.setError(null);
                    tilPromo.setHelperText(null);
                    recalcTotalsFor(selectedMethod); // tính lại KHÔNG giảm giá
                }
            });
        }
    }

    private void hideKeyboard() {
        try {
            InputMethodManager imm = (InputMethodManager) requireContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            View v = getView();
            if (imm != null && v != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        } catch (Exception ignore) {}
    }

    private boolean isValidPromo(@NonNull String code) {
        return "GIAM10".equalsIgnoreCase(code) || "SALE10".equalsIgnoreCase(code);
    }

    @NonNull
    private String getPromoText() {
        if (tilPromo != null && tilPromo.getEditText() != null) {
            return String.valueOf(tilPromo.getEditText().getText()).trim();
        }
        return "";
    }

    // ---------------- Bundle vé ----------------
    private long parseCurrencyTextView(TextView tv) {
        try {
            String s = tv.getText().toString().replaceAll("[^\\d]", "");
            return Long.parseLong(s);
        } catch (Exception e) { return 0L; }
    }

    private Bundle buildTicketBundle() {
        Bundle b = new Bundle();
        String ticketId = (lastPaymentResult != null && lastPaymentResult.getTransactionId() != null)
                ? lastPaymentResult.getTransactionId()
                : "TX-" + System.currentTimeMillis();
        long totalPaid = parseCurrencyTextView(tvTotal);

        b.putString("ticketId", ticketId);
        b.putString("eventTitle", eventTitleArg);
        b.putString("showId", showId);
        b.putStringArray("seats", seats.toArray(new String[0]));
        b.putLong("totalPaid", totalPaid);

        // NEW: gửi kèm phương thức thanh toán để MyTickets & TicketDetail hiển thị
        String methodLabel = (authorizedMethod != null)
                ? paymentMethodLabel(authorizedMethod)
                : "ĐÃ THANH TOÁN";
        b.putString("paymentMethod", methodLabel);

        return b;
    }

    @NonNull
    private String paymentMethodLabel(@NonNull PaymentMethod m) {
        switch (m) {
            case CARD:
                return "Thẻ (Card)";
            case WALLET:
                return "Ví điện tử";
            case QR:
                return "QR Banking";
            default:
                return "ĐÃ THANH TOÁN";
        }
    }

    // ---------------- Authorize ----------------
    private void startAuthorize(@NonNull PaymentMethod method) {
        if (seats.isEmpty() || ticketPrice <= 0L) {
            Snackbar.make(requireView(), "Giỏ vé không hợp lệ.", Snackbar.LENGTH_SHORT).show();
            return;
        }
        if (isProcessing) return;

        // Dùng CHỈ appliedPromoCode (đã tick ✅)
        long base      = ticketPrice;
        long discount  = applyPromoDiscount(appliedPromoCode, base);
        long subTotal  = Math.max(0L, base - discount);
        long fee       = calcServiceFeeByMethod(subTotal, method);
        long grandTotal= subTotal + fee;

        // Đồng bộ UI trước khi gọi provider
        updatePriceUi(base, discount, fee, grandTotal);

        setUiEnabled(false);
        isProcessing = true;

        PaymentRequest req = new PaymentRequest(
                eventId, showId, seats, grandTotal, "VND", appliedPromoCode, null
        );

        payments.pay(this, method, req, new PaymentCallback() {
            @Override
            public void onSuccess(PaymentResult result) {
                showProcessingDialog("Đang xác minh thanh toán...");
                ui.postDelayed(() -> showProcessingTickThenDismiss(() -> {
                    isProcessing = false;

                    isAuthorized = true;
                    authorizedMethod = method;
                    lastPaymentResult = result;
                    paymentLocked = true;

                    lockPaymentMethodButtons();
                    lockPromoField();
                    btnConfirm.setEnabled(true);

                    new MaterialAlertDialogBuilder(requireContext())
                            .setTitle("Xác nhận thành công")
                            .setMessage("Đã xác nhận thanh toán qua " + result.getProvider() +
                                    "\nMã giao dịch: " + result.getTransactionId() +
                                    "\n\nBạn có thể bấm “Nhận vé” để xem vé của mình.")
                            .setPositiveButton("Đã hiểu", null)
                            .show();
                }), 600);
            }

            @Override
            public void onFailure(PaymentResult result) {
                isProcessing = false;
                paymentLocked = false;

                setUiEnabled(true);
                unlockPromoField();

                isAuthorized = false;
                authorizedMethod = null;
                lastPaymentResult = null;
                btnConfirm.setEnabled(false);

                Snackbar.make(requireView(),
                        "Xác nhận thất bại: " +
                                (result.getMessage() == null ? "Không rõ lỗi" : result.getMessage()),
                        Snackbar.LENGTH_LONG).show();
            }
        });
    }

    // ---------------- Dialog processing ----------------
    private void showProcessingDialog(@NonNull String message) {
        if (!isAdded()) return;

        if (processingView == null) {
            processingView = getLayoutInflater().inflate(R.layout.dialog_processing, null, false);
            progressBar = processingView.findViewById(R.id.progress);
            ivTick      = processingView.findViewById(R.id.iv_tick);
            tvProcessingMsg = processingView.findViewById(R.id.tv_processing_msg);
        }
        progressBar.setVisibility(View.VISIBLE);
        ivTick.setVisibility(View.GONE);
        tvProcessingMsg.setText(message);

        if (processingDialog == null) {
            processingDialog = new AlertDialog.Builder(requireContext())
                    .setView(processingView)
                    .setCancelable(false)
                    .create();
            processingDialog.setCanceledOnTouchOutside(false);
        }
        if (!processingDialog.isShowing()) processingDialog.show();
    }

    private void showProcessingTickThenDismiss(@NonNull Runnable after) {
        if (!isAdded() || processingView == null) { after.run(); return; }

        progressBar.setVisibility(View.GONE);
        ivTick.setScaleX(0.6f);
        ivTick.setScaleY(0.6f);
        ivTick.setAlpha(0f);
        ivTick.setVisibility(View.VISIBLE);
        tvProcessingMsg.setText("Đã xác minh thành công");

        ivTick.animate()
                .alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(220)
                .withEndAction(() ->
                        new Handler(Looper.getMainLooper()).postDelayed(() -> {
                            dismissProcessingDialog();
                            after.run();
                        }, 1200))
                .start();
    }

    private void dismissProcessingDialog() {
        if (processingDialog != null && processingDialog.isShowing()) {
            try { processingDialog.dismiss(); } catch (Exception ignore) {}
        }
    }

    @Override public void onDestroyView() {
        dismissProcessingDialog();
        processingDialog = null;
        processingView = null;
        progressBar = null;
        ivTick = null;
        tvProcessingMsg = null;
        super.onDestroyView();
    }

    // ---------------- UI & tính phí ----------------
    private void setSelection(@NonNull PaymentMethod method) {
        selectedMethod = method;
        setChecked(btnCard,   method == PaymentMethod.CARD);
        setChecked(btnWallet, method == PaymentMethod.WALLET);
        setChecked(btnQr,     method == PaymentMethod.QR);
        recalcTotalsFor(method);
    }

    private void recalcTotalsFor(@NonNull PaymentMethod method) {
        long base     = ticketPrice;
        long discount = applyPromoDiscount(appliedPromoCode, base);   // ❗ chỉ dùng appliedPromoCode
        long subTotal = Math.max(0L, base - discount);
        long fee      = calcServiceFeeByMethod(subTotal, method);
        long total    = subTotal + fee;

        updatePriceUi(base, discount, fee, total);
    }

    private void updatePriceUi(long base, long discount, long fee, long total) {
        tvTicketPrice.setText(vnd.format(base));

        if (rowDiscount != null) {
            if (discount > 0) {
                rowDiscount.setVisibility(View.VISIBLE);
                if (tvDiscount != null) tvDiscount.setText("-" + vnd.format(discount));
            } else {
                rowDiscount.setVisibility(View.GONE);
            }
        }

        tvServiceFee.setText(vnd.format(fee));
        tvTotal.setText(vnd.format(total));
    }

    private void setUiEnabled(boolean enabled) {
        boolean methodsEnabled = enabled && !isProcessing && !paymentLocked;
        if (paymentButtons != null) for (MaterialButton b : paymentButtons) if (b != null) b.setEnabled(methodsEnabled);
        if (btnConfirm != null) btnConfirm.setEnabled(enabled && isAuthorized);

        if (tilPromo != null && etPromo != null) {
            boolean promoEnabled = enabled && !isProcessing && !paymentLocked;
            tilPromo.setEnabled(promoEnabled);
            etPromo.setEnabled(promoEnabled);
        }
    }

    private void lockPaymentMethodButtons() {
        if (paymentButtons != null) {
            for (MaterialButton b : paymentButtons) if (b != null) b.setEnabled(false);
        }
    }

    private void lockPromoField() {
        if (tilPromo != null) tilPromo.setEnabled(false);
        if (etPromo != null)  etPromo.setEnabled(false);
    }

    private void unlockPromoField() {
        if (tilPromo != null) tilPromo.setEnabled(true);
        if (etPromo != null)  etPromo.setEnabled(true);
    }

    private long calcServiceFee(long base) {
        if (base <= 0) return 0L;
        long fee = Math.round(base * SERVICE_FEE_RATE);
        return Math.max(fee, SERVICE_FEE_MIN);
    }

    private long calcServiceFeeByMethod(long base, @NonNull PaymentMethod m) {
        long fee = calcServiceFee(base);
        if (m == PaymentMethod.QR) fee = Math.round(fee * 0.7);
        return Math.max(0L, fee);
    }

    private long applyPromoDiscount(String code, long baseTicketPrice) {
        if (code == null || code.isEmpty()) return 0L;
        if ("GIAM10".equalsIgnoreCase(code) || "SALE10".equalsIgnoreCase(code)) {
            return Math.round(baseTicketPrice * 0.10);
        }
        return 0L;
    }

    @Nullable
    private PaymentMethod idToMethod(@IdRes int id) {
        if (id == R.id.btn_payment_card)   return PaymentMethod.CARD;
        if (id == R.id.btn_payment_wallet) return PaymentMethod.WALLET;
        if (id == R.id.btn_payment_qr)     return PaymentMethod.QR;
        return null;
    }

    private void setChecked(@Nullable MaterialButton b, boolean checked) {
        if (b != null) b.setChecked(checked);
    }

    @Nullable
    private TextInputLayout findFirstTextInputLayout(@Nullable ViewGroup root) {
        if (root == null) return null;
        for (int i = 0; i < root.getChildCount(); i++) {
            View c = root.getChildAt(i);
            if (c instanceof TextInputLayout) return (TextInputLayout) c;
            if (c instanceof ViewGroup) {
                TextInputLayout found = findFirstTextInputLayout((ViewGroup) c);
                if (found != null) return found;
            }
        }
        return null;
    }
}
