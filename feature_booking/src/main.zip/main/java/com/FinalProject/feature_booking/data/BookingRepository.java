package com.FinalProject.feature_booking.data;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.FinalProject.core.constName.StoreField;
import com.FinalProject.feature_booking.model.TicketType;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * BookingRepository – nói chuyện trực tiếp với Firestore cho feature booking.
 *
 * DB_Structure liên quan:
 *
 * Events (collection)
 *  └── {event_id}
 *       └── Tickets_infor (subcollection)
 *            └── {tickets_infor_id}
 *                 ├── tickets_class    (STD / VIP / VVIP)
 *                 ├── tickets_price
 *                 ├── tickets_quantity
 *                 └── tickets_sold
 *
 * Orders (collection)
 *  └── {orderId}
 *       ├── user_id
 *       ├── total_price
 *       ├── is_paid              (boolean)
 *       ├── payment_method
 *       ├── event_id
 *       ├── show_id
 *       ├── qr_code              (tạm để "")
 *       └── ticket_items: [ { tickets_infor_id, tickets_class, quantity, price_each }, ... ]
 */
public class BookingRepository {

    private static volatile BookingRepository INSTANCE;
    private final FirebaseFirestore db;

    private BookingRepository() {
        db = FirebaseFirestore.getInstance();
    }

    public static BookingRepository getInstance() {
        if (INSTANCE == null) {
            synchronized (BookingRepository.class) {
                if (INSTANCE == null) {
                    INSTANCE = new BookingRepository();
                }
            }
        }
        return INSTANCE;
    }

    // ---------- EVENTS ----------

    public Task<DocumentSnapshot> getEventDocument(@NonNull String eventId) {
        return db.collection(StoreField.EVENTS)
                .document(eventId)
                .get();
    }

    // ---------- tickets_infor RAW ----------

    public Task<QuerySnapshot> getTicketInfos(@NonNull String eventId) {
        return db.collection(StoreField.EVENTS)
                .document(eventId)
                .collection(StoreField.TICKETS_INFOR)
                .get();
    }

    // ---------- TicketType cho UI (BookingActivity / EventDetail) ----------

    /**
     * Map subcollection Tickets_infor -> List<TicketType> cho UI.
     * typeId = tickets_class (STD/VIP/VVIP), displayName = cùng giá trị.
     */
    public Task<List<TicketType>> getTicketTypesForEvent(@NonNull String eventId) {
        return getTicketInfos(eventId).continueWith(task -> {
            if (!task.isSuccessful() || task.getResult() == null) {
                Exception e = task.getException();
                if (e != null) throw e;
                throw new IllegalStateException("Không tải được tickets_infor");
            }

            QuerySnapshot snap = task.getResult();
            List<TicketType> list = new ArrayList<>();

            for (DocumentSnapshot doc : snap.getDocuments()) {
                String cls = doc.getString(StoreField.TicketFields.TICKETS_CLASS);
                Long priceLong = doc.getLong(StoreField.TicketFields.TICKETS_PRICE);
                Long qtyLong = doc.getLong(StoreField.TicketFields.TICKETS_QUANTITY);
                Long soldLong = doc.getLong(StoreField.TicketFields.TICKETS_SOLD);

                if (cls == null || priceLong == null) continue;

                long totalQty = qtyLong != null ? qtyLong : 0L;
                long soldQty  = soldLong != null ? soldLong : 0L;
                long left     = Math.max(0L, totalQty - soldQty);

                // typeId = tickets_class (STD/VIP/VVIP), displayName = cùng giá trị
                list.add(new TicketType(cls, cls, priceLong, totalQty, left));
            }

            return list;
        });
    }

    // ---------- Tạo Order trong collection Orders ----------

    /**
     * Tạo Order trong collection Orders theo StoreField:
     *
     * Orders (collection)
     *  └── {orderId} (document)
     *       ├── user_id
     *       ├── total_price
     *       ├── is_paid              (boolean)
     *       ├── payment_method
     *       ├── event_id
     *       ├── show_id
     *       ├── qr_code
     *       └── ticket_items: [ { tickets_infor_id, tickets_class, quantity, price_each }, ... ]
     *
     * @param userId    uid/email của user
     * @param eventId   id sự kiện
     * @param showId    id suất diễn (demo, có thể "" cũng được)
     * @param qtyByType key = tickets_class (STD/VIP/VVIP), value = quantity
     */
    public Task<DocumentReference> createOrder(@NonNull String userId,
                                               @NonNull String eventId,
                                               @Nullable String showId,
                                               @NonNull Map<String, Integer> qtyByType) {

        if (qtyByType.isEmpty()) {
            return Tasks.forException(
                    new IllegalArgumentException("Không có vé nào được chọn.")
            );
        }

        // Bước 1: load Tickets_infor để map typeId -> docId, price
        return getTicketInfos(eventId).continueWithTask(task -> {
            if (!task.isSuccessful() || task.getResult() == null) {
                Exception e = task.getException();
                if (e != null) throw e;
                throw new IllegalStateException("Không tải được tickets_infor");
            }

            QuerySnapshot snap = task.getResult();
            List<Map<String, Object>> ticketList = new ArrayList<>();
            long totalPrice = 0L;

            for (Map.Entry<String, Integer> entry : qtyByType.entrySet()) {
                String typeId = entry.getKey();
                int qty = entry.getValue();
                if (qty <= 0) continue;

                // tìm doc Tickets_infor có tickets_class = typeId
                DocumentSnapshot matchedDoc = null;
                for (DocumentSnapshot doc : snap.getDocuments()) {
                    String cls = doc.getString(StoreField.TicketFields.TICKETS_CLASS);
                    if (cls != null && cls.equalsIgnoreCase(typeId)) {
                        matchedDoc = doc;
                        break;
                    }
                }
                if (matchedDoc == null) {
                    // Không tìm thấy tickets_infor tương ứng => bỏ qua
                    continue;
                }

                String ticketInforId = matchedDoc.getId();
                String cls = matchedDoc.getString(StoreField.TicketFields.TICKETS_CLASS);
                Long priceLong = matchedDoc.getLong(StoreField.TicketFields.TICKETS_PRICE);
                long priceEach = priceLong != null ? priceLong : 0L;

                Map<String, Object> item = new HashMap<>();
                item.put("tickets_infor_id", ticketInforId);
                item.put("tickets_class", cls);
                item.put("quantity", qty);
                item.put("price_each", priceEach);

                ticketList.add(item);
                totalPrice += priceEach * qty;
            }

            if (ticketList.isEmpty()) {
                throw new IllegalStateException("Không có vé hợp lệ để tạo đơn hàng.");
            }

            Map<String, Object> orderData = new HashMap<>();
            orderData.put(StoreField.OrderFields.USER_ID, userId);
            orderData.put(StoreField.OrderFields.TOTAL_PRICE, totalPrice);
            orderData.put(StoreField.OrderFields.IS_PAID, true);                 // boolean
            orderData.put(StoreField.OrderFields.PAYMENT_METHOD, "booking_demo"); // hoặc "cash", "online", ...
            orderData.put("event_id", eventId);
            orderData.put("show_id", showId == null ? "" : showId);
            orderData.put("qr_code", ""); // TODO: có thể generate sau
            orderData.put(StoreField.OrderFields.TICKET_ITEMS, ticketList);      // đúng key ticket_items

            return db.collection(StoreField.ORDERS)
                    .add(orderData);
        });
    }

    // ---------- Orders: lấy danh sách đơn của 1 user ----------

    public Task<QuerySnapshot> getOrdersForUser(@NonNull String userId) {
        return db.collection(StoreField.ORDERS)
                .whereEqualTo(StoreField.OrderFields.USER_ID, userId)
                .get();
    }

    // ---------- Lấy 1 Order theo ID (dùng cho TicketDetail) ----------

    public Task<DocumentSnapshot> getOrderById(@NonNull String orderId) {
        return db.collection(StoreField.ORDERS)
                .document(orderId)
                .get();
    }
}
