package com.FinalProject.feature_booking.model;
public enum TicketStatus { UPCOMING, HISTORY, SHARED }
